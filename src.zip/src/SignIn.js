import { useState } from "react"
import { Form, Navigate, useNavigate } from "react-router-dom"
import Header from "./Component/Header"


function SignIn(){
    const [email,setEmail]= useState('')
    const [password,setPassword]=useState('')
            const navigate=useNavigate()

     const handlesubmit = (e)=>{
    e.preventDefault();
    // alert("entered prevent default");
    navigate('/ProductList');
   }
   
    return(
        <div>

       <h1><u>Login to Skin Cart</u></h1>
            <table align="center" className="register-container">
                <tr>
                    <th>Username:</th>
                    <td><input 
                    class="form-field"
                        type="email"
                        value={email} 
                        placeholder="Enter username" 
                        onChange={(event)=>setEmail(event.target.value)} required>
                        </input> 
                    </td>    
                </tr>
                <tr>
                    <th>Password:</th>
                    <td><input 
                    class="form-field"
                    type="password"
                        value={password} 
                        placeholder="Enter password" 
                        onChange={(event)=>setPassword(event.target.value)}required>
                        </input>
                    </td>
                </tr>
                <button type="submit" onClick={handlesubmit}>Login</button>
            </table>
            <br></br>
        
              
        
            
    </div>
    )
}

export default SignIn

