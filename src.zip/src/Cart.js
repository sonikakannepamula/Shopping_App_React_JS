import React from 'react';
import { useCart } from './CartContext';
import ConfigureCart1 from './ConfigureCart1';

const Cart = () => {
  const { cart, removeFromCart } = useCart(); 
  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price) * item.quantity, 0).toFixed(2);
  };

  return (
    <div className='product-list1'>
      <h1>Your Cart</h1>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
            {cart.map((item) => (
            <div key={item.id} className='product-cart'>
                <img src={item.image_link} alt={item.name} style={{ width: '150px', height: '150px' }} /><br></br>
                {item.name} <br></br>
                ₹{item.price} X {item.quantity}
                <button onClick={() => removeFromCart(item.id)}>Remove</button>
                </div>
            ))}
          
          <p><strong>Total: ₹{getTotalPrice()}</strong></p>
        </div>
      )}
      {/* <ConfigureCart1 cart={cart}/> */}
    </div>
  );
};

export default Cart;


