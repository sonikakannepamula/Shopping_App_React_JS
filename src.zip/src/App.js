// import logo from './logo.svg';
import React from 'react';
import './App.css';
import Header from './Component/Header';
import Footer from './Component/Footer';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from './CartContext';
import Cart from './Cart';
import Products from './Sample';
import Register from './Register';
import SignIn from './SignIn';
import ProductList from './ProductList';
import ConfigureCart from './ConfigureCart';
import ConfigureCart1 from './ConfigureCart1';
import ProductList1 from './Component/ProductList1';
import ProductList2 from './Component/Products';
import App1 from './RegisterUser';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path='/' element={<Register/>}/>
         <Route path='/Login' element={<SignIn/>}/>
         <Route path='/ProductList' element={<ConfigureCart/>}/>
         <Route path='/Cart' element={<ConfigureCart1/>}/>
      </Routes>
      
      </BrowserRouter>
  
    </div>
  );
}

export default App;
