import React, { useState } from 'react';

const ProductList1 = () => {
  // State for storing registered users
  const [users, setUsers] = useState([]);

  // State for form inputs (registration and login)
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [message, setMessage] = useState('');

  // Handle registration form submission
  const handleRegister = (event) => {
    event.preventDefault();

    // Check if the user is already registered
    const userExists = users.some(user => user.email === regEmail);
    if (userExists) {
      setMessage('User already exists!');
      return;
    }

    // Save the new user to the users array
    const newUser = { name: regName, email: regEmail, password: regPassword };
    setUsers([...users, newUser]);

    // Reset registration form
    setRegName('');
    setRegEmail('');
    setRegPassword('');
    setMessage('Registration successful!');
  };

  // Handle login form submission
  const handleLogin = (event) => {
    event.preventDefault();

    // Check if the user exists and the password matches
    const user = users.find(user => user.email === loginEmail && user.password === loginPassword);

    if (user) {
      setMessage('Login successful!');
    } else {
      setMessage('Invalid email or password!');
    }

    // Reset login form
    setLoginEmail('');
    setLoginPassword('');
  };

  return (
    <div>
      <h2>Registration Form</h2>
      <form onSubmit={handleRegister}>
        <input
          type="text"
          placeholder="Enter name"
          value={regName}
          onChange={(e) => setRegName(e.target.value)}
        />
        <input
          type="email"
          placeholder="Enter email"
          value={regEmail}
          onChange={(e) => setRegEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Enter password"
          value={regPassword}
          onChange={(e) => setRegPassword(e.target.value)}
        />
        <button type="submit">Register</button>
      </form>

      <h2>Login Form</h2>
      <form onSubmit={handleLogin}>
        <input
          type="email"
          placeholder="Enter email"
          value={loginEmail}
          onChange={(e) => setLoginEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Enter password"
          value={loginPassword}
          onChange={(e) => setLoginPassword(e.target.value)}
        />
        <button type="submit">Login</button>
      </form>

      <p>{message}</p>
    </div>
  );
};

export default ProductList1;
